package be.marbleous.wml2.Activities;

/**
 * Created by jonasvermeulen on 20/08/16.
 */

public enum ScanType {

    PickslipScan,

    LocationScan,

    ProductScan,


}

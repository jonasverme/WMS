package be.marbleous.wml2.Activities.GoodsReceipt;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import be.marbleous.wml2.R;

public class GoodsReceiptActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goods_receipt);
    }

}

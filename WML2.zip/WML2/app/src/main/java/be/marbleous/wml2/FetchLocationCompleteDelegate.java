package be.marbleous.wml2;

import android.location.Location;

/**
 * Created by jonasvermeulen on 18/04/15.
 */
public interface FetchLocationCompleteDelegate {
    public void FetchCompleteResult(Location location);
}

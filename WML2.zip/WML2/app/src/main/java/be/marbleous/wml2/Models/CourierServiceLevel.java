package be.marbleous.wml2.Models;

/**
 * Created by jonasvermeulen on 09/10/15.
 */
public class CourierServiceLevel {



    public String Active;
    public String Code;
    public String Description;
    public String Id;
    public String TransSmartId;
}

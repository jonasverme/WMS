package be.marbleous.wml2.Models;

/**
 * Created by jonasvermeulen on 04/04/15.
 */
public class Product {

    public Product()
    {

    }

    public String Active;
    public String Code;
    public String Ean13;
    public String ImageBase64;
    public String Name;
    public String SalesPriceBasic;
    public String TrackTrace;
}

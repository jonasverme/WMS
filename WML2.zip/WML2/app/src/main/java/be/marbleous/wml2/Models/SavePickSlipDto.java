package be.marbleous.wml2.Models;

import java.util.List;

/**
 * Created by jonasvermeulen on 26/10/15.
 */
public class SavePickSlipDto {


    public int Id;

    public List<SavePickSlipLineDto> SavePickSlipLineDto;

}

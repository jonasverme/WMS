package be.marbleous.wml2.Models;

/**
 * Created by jonasvermeulen on 04/04/15.
 */
public class ReservationLocation {

    public ReservationLocation()
    {

    }

    public String BatchNumber;
    public int Id;
    public String Quantity;
    public String ReservationDate;

    public StockLocation StockLocation;


}

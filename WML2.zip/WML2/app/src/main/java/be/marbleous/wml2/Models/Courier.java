package be.marbleous.wml2.Models;

import java.util.List;

/**
 * Created by jonasvermeulen on 09/10/15.
 */
public class Courier {

    public boolean Active;
    public String Code;
    public String CourierDescription;
    public String CourierPhoneNumber;
    public int Id;
    public int TransSmartId;

}

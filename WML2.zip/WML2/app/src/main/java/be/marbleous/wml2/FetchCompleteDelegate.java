package be.marbleous.wml2;

import be.marbleous.wml2.Models.Pickslip;

public interface FetchCompleteDelegate{
    public void fetchCompleteResult(Pickslip pickslip);
}

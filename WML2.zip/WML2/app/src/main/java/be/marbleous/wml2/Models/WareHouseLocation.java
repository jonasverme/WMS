package be.marbleous.wml2.Models;

/**
 * Created by jonasvermeulen on 04/04/15.
 */
public class WareHouseLocation {

    public WareHouseLocation(){

    }

    public String Description;
    public String LevelName;
    public String LevelPriority;
    public String LocationName;
    public String RowName;
    public String RowPriority;
    public String ShelveName;
    public String ShelvePriority;
    public String ScanLocationTag;

}

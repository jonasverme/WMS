package be.marbleous.wml2.Models;

import java.util.Date;

/**
 * Created by jonasvermeulen on 26/10/15.
 */
public class SaveReservationLocationDto {

    public int Id;

    public double Quantity;

    public String BatchNumber;

    public Date PickDateTime;

    public String UserNamePicked;

    public String ScannerIdentification;
}

package be.marbleous.wml2;

import android.test.ActivityInstrumentationTestCase2;
import android.widget.Button;


/**
 * Created by jonasvermeulen on 12/04/15.
 */
/*
public class ProcessLocationsActivityTest extends ActivityInstrumentationTestCase2<be.marbleous.wml2.Activities.ProcessLocationsActivity> {

    private ProcessLocationsActivity activity;

    public ProcessLocationsActivityTest()
    {
        super(ProcessLocationsActivity.class);
    }

    public void setUp() throws Exception {
        super.setUp();
        activity = getActivity();


    }

}*/

package be.marbleous.wml2;

import android.test.ActivityInstrumentationTestCase2;
import android.test.TouchUtils;
import android.test.ViewAsserts;
import android.test.suitebuilder.annotation.SmallTest;
import android.text.method.Touch;
import android.widget.Button;

import junit.framework.TestCase;

//import be.marbleous.wml2.Activities.OrderPickActivity;

/**
 * Created by jonasvermeulen on 12/04/15.
 */
/*public class OrderpickTest extends ActivityInstrumentationTestCase2<OrderPickActivity> {

    private OrderPickActivity activity;
    private Button manualInputButton;

    public OrderpickTest() {
        super(OrderPickActivity.class);
    }


    public void setUp() throws Exception {
        super.setUp();
        activity = getActivity();
        manualInputButton = (Button)activity.findViewById(R.id.btnManualInput);



    }



    @SmallTest
    public void testOnManualInputButtonTapPopupVisible(){
        TouchUtils.tapView(this, manualInputButton);
        ViewAsserts.assertOnScreen(manualInputButton.getRootView(), manualInputButton);

    }




    public void tearDown() throws Exception {

    }


}*/
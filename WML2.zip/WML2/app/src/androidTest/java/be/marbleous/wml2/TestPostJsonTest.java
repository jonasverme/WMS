package be.marbleous.wml2;

import android.test.InstrumentationTestCase;

/**
 * Created by jonasvermeulen on 15/04/15.
 */
public class TestPostJsonTest extends InstrumentationTestCase {

  //  private TestH d ;
    public void setUp() throws Exception {
        super.setUp();





    }




    public void tearDown() throws Exception {

    }
}